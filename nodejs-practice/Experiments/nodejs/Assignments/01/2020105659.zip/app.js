// mymodule.js에 정의된 모듈로 불러서 사용하도록 처리
var mymodule = require('./mymodule');

console.log(mymodule.add(4, 7));
console.log(mymodule.sub(6, 2));